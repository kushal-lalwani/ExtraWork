from rest_framework import serializers
from .models import TestResult

class TestResultSerializer(serializers.ModelSerializer):
    class Meta:
        model = TestResult
        fields = ['id', 'user_profile', 'wpm', 'accuracy', 'test_date', 'test_time', 'text_type', 'test_graph_url']
