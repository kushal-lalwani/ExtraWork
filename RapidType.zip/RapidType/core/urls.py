from django.urls import path, include
from rest_framework.routers import DefaultRouter
from .views import *


router = DefaultRouter()
router.register(r'test-results', TestResultViewSet)

urlpatterns = [
    path('', include(router.urls)),
    path('signup/', UserSignupView.as_view(), name='signup'),
    path('login/', LoginView.as_view(), name='login'),
    path('text/',TextPrompt.as_view(),name='text'),
    path('generate-graph',GenerateGraphView.as_view(),name='generate-graph'),
    path('save-test',SaveTestResultView.as_view()),
]
    