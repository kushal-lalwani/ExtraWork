from django.shortcuts import render

# Create your views here.
from rest_framework import viewsets
from .models import *
from .serializers import *
from django.contrib.auth.models import User
from django.contrib.auth import authenticate
from rest_framework import status
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework.permissions import AllowAny
from rest_framework_simplejwt.tokens import RefreshToken
import json
import io
import plotly.graph_objects as go
from cloudinary import CloudinaryImage
from cloudinary.uploader import upload
from django.shortcuts import get_object_or_404
from django.test import RequestFactory


class TestResultViewSet(viewsets.ModelViewSet):
    queryset = TestResult.objects.all()
    serializer_class = TestResultSerializer

class UserSignupView(APIView):
    permission_classes = [AllowAny]

    def post(self, request):
        username = request.data.get('username')
        email = request.data.get('email')
        password = request.data.get('password')

        if not username or not email or not password:
            return Response({'error': 'Username, email, and password are required'}, status=status.HTTP_400_BAD_REQUEST)

        if User.objects.filter(username=username).exists():
            return Response({'error': 'Username already exists'}, status=status.HTTP_400_BAD_REQUEST)

        user = User.objects.create_user(username=username, email=email, password=password)
        UserProfile.objects.create(user=user)

        return Response({'message': 'User created successfully'}, status=status.HTTP_201_CREATED)

class LoginView(APIView):
    permission_classes = [AllowAny]

    def post(self, request):
        username = request.data.get('username')
        password = request.data.get('password')
        user = authenticate(request, username=username, password=password)

        if user is not None:
            refresh = RefreshToken.for_user(user)
            user_profile = UserProfile.objects.get(user=user)

            return Response({
                'refresh': str(refresh),
                'access': str(refresh.access_token),
                'user_id': user.id,
                'username': user.username,
            }, status=status.HTTP_200_OK)
        else:
            return Response({'error': 'Invalid credentials'}, status=status.HTTP_401_UNAUTHORIZED)


class TextPrompt(APIView):
    def get(self, request):
        text_type = request.GET.get('textType')
        file_mapping = {
            '1': 'words.txt',
            '2': 'punctuation.txt',
            '3': 'topRow.txt',
            '4': 'homeRow.txt',
            '5': 'bottomRow.txt'
        }

        file_name = file_mapping.get(text_type)
        if not file_name:
            return Response({'error': 'Invalid textType'}, status=400)

        try:
            response = s3_client.get_object(Bucket='your-bucket-name', Key=f'textFiles/{file_name}')
            content = response['Body'].read().decode('utf-8')
        except Exception as e:
            return Response({'error': 'File not found or unable to retrieve'}, status=404)

        return Response({'text': content})


class GenerateGraphView(APIView):
    def post(self, request):
        if request.method == 'POST':
            try:
                data = json.loads(request.body.decode('utf-8'))
                wpm_data = data.get('wpm_data', [])
                if not wpm_data:
                    return Response({'error': 'No wpm_data provided'}, status=status.HTTP_400_BAD_REQUEST)

                # Generate x-axis points
                step_size = 3
                x_axis_points = [i * step_size for i in range(1, len(wpm_data) + 1)]

                # Create the Plotly figure
                fig = go.Figure()
                fig.add_trace(go.Scatter(x=x_axis_points, y=wpm_data, mode='lines', line=dict(color='#e2bb39')))
                fig.update_layout(
                    title='Words Per Minute (WPM)',
                    xaxis=dict(
                        title='Time Interval',
                        color='#e2bb39',
                        showgrid=True,
                        gridcolor='#555',
                        gridwidth=0.5
                    ),
                    yaxis=dict(
                        title='WPM',
                        color='#e2bb39',
                        showgrid=True,
                        gridcolor='#555',
                        gridwidth=0.5
                    ),
                    plot_bgcolor='#22252d',
                    paper_bgcolor='#22252d',
                    font=dict(color='#e2bb39', size=12),
                    margin=dict(l=40, r=40, t=60, b=40),
                )

                # Save the figure to a bytes buffer
                image_stream = io.BytesIO()
                fig.write_image(image_stream, format='png')
                image_stream.seek(0)

                # Upload the image to Cloudinary
                cloudinary_response = upload(image_stream, resource_type='image', public_id='generated_graph')
                graph_url = cloudinary_response.get('secure_url')

                return Response({'graph_url': graph_url}, status=status.HTTP_200_OK)

            except Exception as e:
                return Response({'error': f'Invalid request: {str(e)}'}, status=status.HTTP_400_BAD_REQUEST)


class SaveTestResultView(APIView):
    def post(self, request):
        if request.method == 'POST':
            try:
                data = json.loads(request.body.decode('utf-8'))

                # Extract data from request
                wpm = data.get('wpm')
                wpm_data = data.get('wpm_data', [])
                accuracy = data.get('accuracy')
                user_id = data.get('user_id')

                if wpm is None or not wpm_data or accuracy is None or not user_id:
                    return Response({'error': 'wpm, wpm_data, accuracy, and user_id are required'}, status=status.HTTP_400_BAD_REQUEST)

                # Generate the graph using the GenerateGraphView API
                generate_graph_request = RequestFactory().post('/generate-graph/', json.dumps({'wpm_data': wpm_data}), content_type='application/json')
                generate_graph_response = GenerateGraphView().post(generate_graph_request)
                
                if generate_graph_response.status_code != status.HTTP_200_OK:
                    return Response({'error': 'Failed to generate graph'}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)

                print(generate_graph_response.data['graph_url'])
                graph_url = generate_graph_response.data.get('graph_url')
                print(graph_url)
                # Save the test result
                user_profile = get_object_or_404(UserProfile, user__id=user_id)
                print(user_profile)
                test_result = TestResult(
                    user_profile=user_profile,
                    wpm=wpm,
                    accuracy=accuracy,
                    text_type='sample',  # Adjust as needed
                    test_graph_url=graph_url,  # Directly use the graph_url
                )
                print(test_result)
                test_result.save()

                # Serialize and return the response
                serializer = TestResultSerializer(test_result)
                return Response({
                    'test_result': serializer.data,
                    'graph_url': graph_url,
                    'message': 'Test result saved successfully'
                }, status=status.HTTP_201_CREATED)

            except Exception as e:
                return Response({'error': f'Invalid request: {str(e)}'}, status=status.HTTP_400_BAD_REQUEST)
